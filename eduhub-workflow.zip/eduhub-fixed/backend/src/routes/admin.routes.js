/**
 * Admin Routes — compatibility shim for frontend-html shared.js
 * Wraps the Postgres-backed student/lecturer/user queries under /api/admin/*
 */
const express = require('express');
const router  = express.Router();
const sequelize = require('../config/database');
const { authenticateToken } = require('../middleware/auth.middleware');
const { adminOnly } = require('../middleware/roleCheck.middleware');

router.use(authenticateToken, adminOnly);

// GET /api/admin/users
router.get('/users', async (req, res, next) => {
  try {
    const users = await sequelize.query(
      `SELECT u.id as user_id, u.email, u.role, u.account_status, u.created_at,
              u.is_default_password, u.require_password_change,
              ud.first_name, ud.last_name, ud.phone
       FROM users u
       LEFT JOIN user_details ud ON u.id = ud.user_id
       ORDER BY u.created_at DESC`,
      { type: sequelize.QueryTypes.SELECT }
    );
    const out = users.map((user) => ({
      ...user,
      tempPassword: Boolean(user.require_password_change || user.is_default_password),
    }));
    res.json({ ok: true, users: out, total: out.length });
  } catch (err) { next(err); }
});

// GET /api/admin/statistics
router.get('/statistics', async (req, res, next) => {
  try {
    const [[{ total_students }]] = await sequelize.query(
      `SELECT COUNT(*) AS total_students FROM users WHERE role = 'student'`
    );
    const [[{ total_lecturers }]] = await sequelize.query(
      `SELECT COUNT(*) AS total_lecturers FROM users WHERE role = 'lecturer'`
    );
    const [[{ pending_applications }]] = await sequelize.query(
      `SELECT COUNT(*) AS pending_applications FROM applications WHERE status IN ('pending','under_review')`
    );
    const [[{ total_qualifications }]] = await sequelize.query(
      `SELECT COUNT(*) AS total_qualifications FROM qualifications`
    );
    res.json({
      ok: true,
      stats: {
        totalStudents:       Number(total_students),
        totalLecturers:      Number(total_lecturers),
        pendingApplications: Number(pending_applications),
        totalQualifications: Number(total_qualifications),
      }
    });
  } catch (err) { next(err); }
});

// GET /api/admin/audit-logs
router.get('/audit-logs', async (req, res, next) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 50, 200);
    const logs = await sequelize.query(
      `SELECT id, user_id, action, resource_type, resource_id, created_at
       FROM audit_logs ORDER BY created_at DESC LIMIT ?`,
      { replacements: [limit], type: sequelize.QueryTypes.SELECT }
    ).catch(() => []); // table may not exist yet
    res.json({ ok: true, logs });
  } catch (err) { next(err); }
});

// PUT /api/admin/users/:id/role
router.put('/users/:id/role', async (req, res, next) => {
  try {
    const { role } = req.body;
    const validRoles = ['admin', 'student', 'lecturer'];
    if (!role || !validRoles.includes(role)) {
      return res.status(400).json({ ok: false, message: `role must be one of: ${validRoles.join(', ')}` });
    }
    await sequelize.query(
      `UPDATE users SET role = ?, updated_at = NOW() WHERE id = ?`,
      { replacements: [role, req.params.id] }
    );
    res.json({ ok: true, message: 'Role updated.' });
  } catch (err) { next(err); }
});

// PUT /api/admin/users/:id/status
router.put('/users/:id/status', async (req, res, next) => {
  try {
    const { status } = req.body;
    const validStatuses = ['active', 'inactive', 'suspended', 'blocked', 'terminated'];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({ ok: false, message: `status must be one of: ${validStatuses.join(', ')}` });
    }
    await sequelize.query(
      `UPDATE users SET account_status = ?, updated_at = NOW() WHERE id = ?`,
      { replacements: [status, req.params.id] }
    );
    res.json({ ok: true, message: 'Status updated.' });
  } catch (err) { next(err); }
});

// POST /api/admin/allocate  (admin only — allocate modules to a student via application)
router.post('/allocate', async (req, res, next) => {
  try {
    const { applicationId, modules: moduleCodes, semester, studyYear } = req.body;

    if (!applicationId || !Array.isArray(moduleCodes) || moduleCodes.length === 0) {
      return res.status(400).json({ ok: false, message: 'applicationId and modules[] are required.' });
    }

    // Get the application to find the student
    const [appRows] = await sequelize.query(
      `SELECT a.*, s.id AS student_db_id, s.user_id AS student_user_id
       FROM applications a
       LEFT JOIN users u ON u.email = a.email AND u.role = 'student'
       LEFT JOIN students s ON s.user_id = u.id
       WHERE a.id = ?`,
      { replacements: [applicationId] }
    );
    const app = appRows[0];
    if (!app) {
      return res.status(404).json({ ok: false, message: 'Application not found.' });
    }
    if (!app.student_db_id) {
      return res.status(400).json({ ok: false, message: 'No student account found for this application. The application may not have been approved yet, or the student account has not been created.' });
    }

    // Get module IDs from codes
    const placeholders = moduleCodes.map(() => '?').join(',');
    const [moduleRows] = await sequelize.query(
      `SELECT id, code, name, credits FROM modules WHERE code IN (${placeholders})`,
      { replacements: moduleCodes }
    );

    if (moduleRows.length === 0) {
      return res.status(400).json({ ok: false, message: 'None of the provided module codes were found in the database.' });
    }

    // Get or find a semester record
    const [semesters] = await sequelize.query(
      `SELECT id FROM semesters ORDER BY start_date DESC LIMIT 1`
    );
    const semesterId = semesters[0] ? semesters[0].id : null;

    // Remove existing allocations for this student/semester/year (replace)
    if (semester && studyYear) {
      await sequelize.query(
        `DELETE FROM registrations
         WHERE student_id = ?
           AND semester_id IN (
             SELECT id FROM semesters WHERE EXTRACT(YEAR FROM start_date) = ?
           )`,
        { replacements: [app.student_db_id, studyYear] }
      ).catch(() => {}); // ignore if no matching records
    }

    // Insert registrations
    const created = [];
    for (const mod of moduleRows) {
      const [existing] = await sequelize.query(
        `SELECT id FROM registrations WHERE student_id = ? AND module_id = ?`,
        { replacements: [app.student_db_id, mod.id] }
      );
      if (existing[0]) {
        // Update existing to allocated
        await sequelize.query(
          `UPDATE registrations SET status = 'allocated', updated_at = NOW() WHERE student_id = ? AND module_id = ?`,
          { replacements: [app.student_db_id, mod.id] }
        );
        created.push({ id: existing[0].id, module: mod.code });
      } else {
        const [[reg]] = await sequelize.query(
          `INSERT INTO registrations (student_id, module_id, semester_id, status, created_at, updated_at)
           VALUES (?, ?, ?, 'allocated', NOW(), NOW()) RETURNING id`,
          { replacements: [app.student_db_id, mod.id, semesterId || null] }
        );
        created.push({ id: reg ? reg.id : null, module: mod.code });
      }
    }

    res.status(201).json({
      ok: true,
      message: `${created.length} module(s) allocated successfully.`,
      allocated: created
    });
  } catch (err) { next(err); }
});

module.exports = router;
