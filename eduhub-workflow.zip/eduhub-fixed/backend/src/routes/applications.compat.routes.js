/**
 * Applications compat routes — adds authenticated list/approve/reject
 * on top of the public task-backend application routes.
 * Mounted at /api/applications alongside application.routes.js
 */
const express   = require('express');
const router    = express.Router();
const sequelize = require('../config/database');
const { authenticateToken }      = require('../middleware/auth.middleware');
const { adminOnly, staffOnly }   = require('../middleware/roleCheck.middleware');

// GET /api/applications  (authenticated — admin sees all, student sees own)
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    let applications;
    if (req.user.role === 'admin' || req.user.role === 'lecturer') {
      applications = await sequelize.query(
        `SELECT a.*,
                CASE WHEN a.status = 'rejected' THEN 'declined' ELSE a.status END AS status,
                COALESCE(a.decline_reason, a.rejection_reason) AS decline_reason,
                q.name AS qualification_name, q.code AS qualification_code,
                c.name AS campus_name
         FROM applications a
         LEFT JOIN qualifications q ON a.qualification_id = q.id
         LEFT JOIN campuses c ON a.campus_id = c.id
         ORDER BY a.created_at DESC`,
        { type: sequelize.QueryTypes.SELECT }
      ).catch(() => []);
    } else {
      applications = await sequelize.query(
        `SELECT a.*,
                CASE WHEN a.status = 'rejected' THEN 'declined' ELSE a.status END AS status,
                COALESCE(a.decline_reason, a.rejection_reason) AS decline_reason,
                q.name AS qualification_name, q.code AS qualification_code,
                c.name AS campus_name
         FROM applications a
         LEFT JOIN qualifications q ON a.qualification_id = q.id
         LEFT JOIN campuses c ON a.campus_id = c.id
         WHERE a.email = ?
         ORDER BY a.created_at DESC`,
        { replacements: [req.user.email], type: sequelize.QueryTypes.SELECT }
      ).catch(() => []);
    }
    res.json({ ok: true, applications, total: applications.length });
  } catch (err) { next(err); }
});

// PUT /api/applications/:id/approve  (admin only)
router.put('/:id/approve', authenticateToken, adminOnly, async (req, res, next) => {
  try {
    const id = req.params.id;

    // Fetch the application first
    const apps = await sequelize.query(
      `SELECT * FROM applications WHERE id = ?`,
      { replacements: [id], type: sequelize.QueryTypes.SELECT }
    );
    if (!apps.length) {
      return res.status(404).json({ ok: false, message: 'Application not found.' });
    }
    const app = apps[0];

    // Update status to approved
    await sequelize.query(
      `UPDATE applications SET status = 'approved', updated_at = NOW() WHERE id = ?`,
      { replacements: [id] }
    );

    // Check if a student user account already exists for this email
    const existingUsers = await sequelize.query(
      `SELECT u.id, u.email FROM users u WHERE u.email = ? AND u.role = 'student'`,
      { replacements: [app.email], type: sequelize.QueryTypes.SELECT }
    ).catch(() => []);

    let studentCreated = false;
    let tempPassword = null;

    if (!existingUsers.length) {
      // Create a student user account with a temporary password
      const bcrypt = require('bcrypt');
      tempPassword = `EduHub@${Math.floor(1000 + Math.random() * 9000)}`;
      const hash = await bcrypt.hash(tempPassword, 10);
      const firstName = app.first_name || '';
      const lastName  = app.last_name  || '';

      await sequelize.query(
        `INSERT INTO users (email, password_hash, role, account_status, is_default_password, require_password_change, created_at, updated_at)
         VALUES (?, ?, 'student', 'active', true, true, NOW(), NOW())`,
        { replacements: [app.email, hash] }
      ).catch(() => {}); // ignore if already exists (race condition)

      // Try to update user_details if the table exists
      const newUsers = await sequelize.query(
        `SELECT id FROM users WHERE email = ? AND role = 'student'`,
        { replacements: [app.email], type: sequelize.QueryTypes.SELECT }
      ).catch(() => []);

      if (newUsers.length) {
        await sequelize.query(
          `INSERT INTO user_details (user_id, first_name, last_name, created_at, updated_at)
           VALUES (?, ?, ?, NOW(), NOW())
           ON CONFLICT (user_id) DO NOTHING`,
          { replacements: [newUsers[0].id, firstName, lastName] }
        ).catch(() => {});
      }

      studentCreated = true;
    }

    res.json({
      ok: true,
      message: 'Application approved.',
      studentCreated,
      tempPassword: studentCreated ? tempPassword : null,
    });
  } catch (err) { next(err); }
});

// PUT /api/applications/:id/reject  (admin only)
router.put('/:id/reject', authenticateToken, adminOnly, async (req, res, next) => {
  try {
    const { reason } = req.body;
    await sequelize.query(
      `UPDATE applications SET status = 'rejected', rejection_reason = ?, updated_at = NOW() WHERE id = ?`,
      { replacements: [reason || null, req.params.id] }
    );
    res.json({ ok: true, message: 'Application declined.' });
  } catch (err) { next(err); }
});

// POST /api/applications/:id/documents  (stub)
router.post('/:id/documents', authenticateToken, async (req, res) => {
  res.json({ ok: true, message: 'Document recorded.', documentName: req.body.documentName });
});

module.exports = router;
